<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Interiors 1" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="Tilesets/Set_C_Interiors.png" trans="ff01fe" width="256" height="256"/>
</tileset>
