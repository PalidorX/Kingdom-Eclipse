<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Exteriors" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="Tilesets/Set_B_Exteriors.png" trans="ff01fe" width="256" height="256"/>
</tileset>
