<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Small Town" tilewidth="16" tileheight="16" tilecount="256" columns="16">
 <image source="Tilesets/Set_E_SmallTownA.png" trans="ff01fe" width="256" height="256"/>
 <terraintypes>
  <terrain name="Ceilling1" tile="25"/>
  <terrain name="Ceilling2" tile="105"/>
 </terraintypes>
 <tile id="8" terrain=",,,0"/>
 <tile id="9" terrain=",,0,0"/>
 <tile id="10" terrain=",,0,"/>
 <tile id="11" terrain=",0,0,0"/>
 <tile id="12" terrain="0,,0,0"/>
 <tile id="24" terrain=",0,,0"/>
 <tile id="25" terrain="0,0,0,0"/>
 <tile id="26" terrain="0,,0,"/>
 <tile id="27" terrain="0,0,,0"/>
 <tile id="28" terrain="0,0,0,"/>
 <tile id="40" terrain=",0,,"/>
 <tile id="41" terrain="0,0,,"/>
 <tile id="42" terrain="0,,,"/>
 <tile id="43" terrain=",0,0,"/>
 <tile id="44" terrain="0,,,0"/>
 <tile id="88" terrain=",,,1"/>
 <tile id="89" terrain=",,1,1"/>
 <tile id="90" terrain=",,1,"/>
 <tile id="91" terrain=",1,1,1"/>
 <tile id="92" terrain="1,,1,1"/>
 <tile id="104" terrain=",1,,1"/>
 <tile id="105" terrain="1,1,1,1"/>
 <tile id="106" terrain="1,,1,"/>
 <tile id="107" terrain="1,1,,1"/>
 <tile id="108" terrain="1,1,1,"/>
 <tile id="120" terrain=",1,,"/>
 <tile id="121" terrain="1,1,,"/>
 <tile id="122" terrain="1,,,"/>
 <tile id="123" terrain=",1,1,"/>
 <tile id="124" terrain="1,,,1"/>
</tileset>
